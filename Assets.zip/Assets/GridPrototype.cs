using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GridPrototype : MonoBehaviour
{
    private bool buildModeOn = false;
    private bool canBuild = false;

    public Triggascr Triggascr;

    private Vector3 VR3;
    private Vector3 V3;

    [SerializeField]
    private float GridSize;

    private float mouseWheelRotation = 0f;

    [SerializeField]
    private KeyCode newObjectHotkey = KeyCode.A;
    [SerializeField]
    private GameObject placeableObjectPrefab;
    private GameObject currentPlaceableObject;

    [SerializeField]
    private Slider SensibilitySlider;

    private void Update()
    {
        HandleNewObjectHotkey();
        //GridSensibility = SensibilitySlider.value;
        if (currentPlaceableObject != null && buildModeOn)
        {
            MoveCurrentObjectToMouse();
            RotateFromMouseWheel();
            ReleaseIfClicked();
            Findscr();
        }
    }

    private void LateUpdate()
    {
        V3.x = Mathf.Floor(VR3.x / GridSize) * GridSize;
        V3.y = Mathf.Floor(VR3.y / GridSize) * GridSize;
        V3.z = Mathf.Floor(VR3.z / GridSize) * GridSize;

        if(buildModeOn)
        {
            currentPlaceableObject.transform.position = V3;
        }
    }

    private void HandleNewObjectHotkey()
    {
        if (Input.GetKeyDown(newObjectHotkey))
        {
            if (currentPlaceableObject != null)
            {
                Destroy(currentPlaceableObject);
                buildModeOn = false;
            }
            else
            {
                currentPlaceableObject = Instantiate(placeableObjectPrefab);
                buildModeOn = true;
            }
        }
    }

    private void Findscr()
    {
        Triggascr = currentPlaceableObject.GetComponent<Triggascr>();
    }

    private void MoveCurrentObjectToMouse()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        RaycastHit hitInfo;
        if (Physics.Raycast(ray, out hitInfo))
        {
            VR3 = hitInfo.point + hitInfo.normal /2;
            currentPlaceableObject.transform.rotation = Quaternion.FromToRotation(Vector3.up, hitInfo.normal);
            canBuild = true;
        }
        else
        {
            canBuild = false;
        }
    }

    private void RotateFromMouseWheel()
    {
        mouseWheelRotation += Input.mouseScrollDelta.y;
        currentPlaceableObject.transform.Rotate(Vector3.up, mouseWheelRotation * 10f);
    }

    private void ReleaseIfClicked()
    {
        if (Input.GetMouseButtonDown(1) && canBuild && Triggascr.canBuildTr)
        {
            currentPlaceableObject.layer = LayerMask.NameToLayer("Default");
            buildModeOn = false;
            currentPlaceableObject = null;
        }
    }

}

